function changeImg(imgNumber) {
    	var myImages = ["/etc/styles/Sentora_Default/img/logos/image0.jpg", "/etc/styles/Sentora_Default/img/logos/image1.jpg", "/etc/styles/Sentora_Default/img/logos/image2.jpg", "/etc/styles/Sentora_Default/img/logos/image3.jpg"]; 
    	var imgShown = document.body.style.backgroundImage;
    	var newImgNumber =Math.floor(Math.random()*myImages.length);
    	document.body.style.backgroundImage = 'url('+myImages[newImgNumber]+')';
    }
    window.onload=changeImg;
